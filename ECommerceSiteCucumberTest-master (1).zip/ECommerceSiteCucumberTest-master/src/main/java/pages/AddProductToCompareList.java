package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import CommonActions.BusinessCommonActions;
import CommonActions.ScrollingActions;
import Pages.Step;

public class AddProductToCompareList {
		
	WebDriver driver;

	public CreateOrderPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
		businessCommonActions = new BusinessCommonActions(driver);
		scrollingActions = new ScrollingActions(driver);
	}

	@FindBy(xpath = "/html/body/div[6]/div[2]/ul[1]/li[3]/ul/li[1]/a")
	public WebElement SubCategory;

	@FindBy(className = "page-title")
	public WebElement page_Title;

	@FindBy(className = "add-to-wishlist-button")
	public WebElement WishListBtn;

	@FindBy(className = "add-to-compare-list-button")
	public WebElement CompareListBtn;
	
	
	@Step("Add product to comare list")
	public void AddProductToCompareList() throws InterruptedException {
		Thread.sleep(2000);
		scrollingActions.SwipScreenDownToWebElement(WishListBtn);
		businessCommonActions.ClickOnWebElement(CompareListBtn);
		Thread.sleep(2000);
		Assert.assertEquals("The product has been added to your product comparison", businessCommonActions.getText(NotificationMsg));


	} 
	
	
	
	
	
}
