package pages;

public class ChangeCurrencyOfProduct {

}
